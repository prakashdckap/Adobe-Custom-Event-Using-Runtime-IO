const axios = require('axios');
const xml2js = require('xml2js');

async function fetchXMLData(params) {
    //const url = 'https://akeneo.rdklizer.com/test.xml';
    const xmlData = params["__ow_body"];
    try {
       // const response = await axios.get(url, { responseType: 'text' });
        const result = await xml2js.parseStringPromise(xmlData);
        return { status: "Success", data: result };
    } catch (error) {
        return { status: "Error", message: error.message };
    }
}

exports.main = async (params) => {
    return await fetchXMLData(params);
};
